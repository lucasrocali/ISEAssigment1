//
//  SessionGenerator.swift
//  Assignement1
//
//  Created by Mateus Cirolini on 1/04/2015.
//  Copyright (c) 2015 RMIT. All rights reserved.
//

import Foundation

struct SessionGenerator {
    
    var  day:[Int : String] = [1:"Monday", 2:"Tuesday", 3:"Wednesday",4:"Thursday",5:"Friday",6:"Saturday",7:"Sunday"]
    
    var time:[Int : String] = [1:"12:00 pm", 2:"2:30 pm", 3:"5:00 pm",4:"7:30 pm",5:"10:00 pm"]
}
